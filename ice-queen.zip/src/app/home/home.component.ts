import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(public dataService:DataService){

  }
cards:any= [];
selectedFlavour = [];
selectedFlavourName: string;
selectedFlavourDesc:string;
smallSizePrice:number;
smallSizeQuantity:number;
mediumSizePrice:number;
mediumSizeQuantity:number;
largeSizePrice: number;
largeSizeQuantity: number;
selectedFlavourImg:any;
 
  slides: any = [[]];
  chunk(arr, chunkSize) {
    let R = [];
    for (let i = 0, len = arr.length; i < len; i += chunkSize) {
      R.push(arr.slice(i, i + chunkSize));
    }
    return R;
  }
  ngOnInit() {
    this.dataService.getFlavoursData().subscribe(data =>{
      console.log(data)
      this.cards = data;
      this.slides = this.chunk(this.cards, 4);
    })
    document.getElementById('car').className = 'col-md-12';
  }

  flavourDetails(fid){
    console.log(fid);
    document.getElementById('car').className = 'col-md-8';
    document.getElementById('detail').className = 'show col-md-4';
   // document.getElementById('detail').className = 'show';
    this.selectedFlavour = this.cards.filter(i => fid == i.id);
    this.selectedFlavourName = this.selectedFlavour[0].title;
    this.selectedFlavourDesc = this.selectedFlavour[0].description;
    this.selectedFlavourImg = this.selectedFlavour[0].img;
    this.smallSizePrice = this.selectedFlavour[0].smallSizePrice;
    this.smallSizeQuantity = this.selectedFlavour[0].smallSizeQuantity;
    this.mediumSizePrice = this.selectedFlavour[0].mediumSizePrice;
    this.mediumSizeQuantity = this.selectedFlavour[0].mediumSizeQuantity;
    this.largeSizePrice = this.selectedFlavour[0].largeSizePrice;
    this.largeSizeQuantity = this.selectedFlavour[0].largeSizeQuantity;

  }
  closeDatails(){
    document.getElementById('car').className = 'col-md-12';
    document.getElementById('detail').className = 'hide';
  }
}
